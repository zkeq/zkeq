<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

        </div><!-- end .row -->
    </div>
</div><!-- end #body -->

<footer id="footer" role="contentinfo">
    © <?php echo date('Y'); ?> <a href="http://disixueyuan.com/"><?php $this->options->title(); ?></a>.
    <?php _e('我也要做 <a href="http://disixueyuan.com/index.php/article/15.html">个人博客网站</a> '); ?>.
</footer><!-- end #footer -->

<?php $this->footer(); ?>
</body>
</html>
