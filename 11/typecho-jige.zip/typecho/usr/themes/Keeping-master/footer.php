<?php if (!defined( '__TYPECHO_ROOT_DIR__')) exit; ?>
</div>
</main>
<footer class="footer">
    <div class="copyright">
Copyright © 2019 <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title() ?></a> 的博客<br/>
<?php $this->options->Icp(); ?> • 我也要做 <a href="http://disixueyuan.com/index.php/article/15.html" target="_blank" rel="external nofollow noopener noreffer">个人博客网站</a> • Theme <a href="http://disixueyuan.com/index.php" target="_blank" rel="external nofollow noopener noreffer">第四学院</a>
<script async src="<?php $this->options->themeUrl('js/c41407119fd540ca8be2f3c058b2b3f9.js'); ?>"></script>
<script async src="<?php $this->options->themeUrl('js/1a8f7b3ed5da49b59f465e8fbf83e1a7.js'); ?>"></script>
<script>window.dataLayer =window.dataLayer ||[];function gtag(){dataLayer.push(arguments);}
gtag('js',new Date());gtag('config','UA-110780416-1');</script>
    </div>
</footer>
<script src='<?php $this->options->themeUrl('js/nprogress.js'); ?>'></script>
<script src='<?php $this->options->themeUrl('js/pjax.min.js'); ?>'></script>
<script src='<?php $this->options->themeUrl('js/vendor_main.min.js'); ?>'></script>
<script>
var pjax = new Pjax({
    elements: 'a[href]:not([href^="#"])',
    cacheBust: false,
    debug: false,
    selectors: ['title', '.wrapper'
    ]
});
document.addEventListener('pjax:send', function () {
    NProgress.start();
});
document.addEventListener('pjax:complete', function () {
    NProgress.done();
});
</script>
</div>
</body>

</html>