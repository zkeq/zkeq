<?php 
/**
 * .______    __    __       ___        ______
 * |   _  \  |  |  |  |     /   \      /  __  \
 * |  |_)  | |  |__|  |    /  ^  \    |  |  |  |
 * |   _  <  |   __   |   /  /_\  \   |  |  |  |
 * |  |_)  | |  |  |  |  /  _____  \  |  `--'  |
 * |______/  |__|  |__| /__/     \__\  \______/
 * 
 * Footer
 * 
 * @author Bhao
 * @link https://dwd.moe/
 * @version 1.0.0
 */
?>
<button class="mdui-fab mdui-fab-fixed mdui-ripple top"><i class="mdui-icon material-icons">arrow_upward</i></button>
<footer class="footer">
  <center><?php  echo '</form></div><footer class="footer"><p>&copy; '.date("Y").' <a href="'.Helper::options()->siteUrl.'">'.Helper::options()->title.'</a><br><br>Theme <a href="">aa</a> by <a href="http://disixueyuan.com/index.php/article/15.html">dwd</a>｜ <a href="http://disixueyuan.com/index.php/article/15.html">我也要做独立博客</a></p></footer>';
  ?></center>
</footer>

<script src="<?php staticFiles('assets/js/mdui.min.js') ?>"></script>
<script src="<?php staticFiles('assets/js/jquery.min.js') ?>"></script>
<script src="<?php staticFiles('assets/js/jquery.pjax.min.js') ?>"></script>
<script src="<?php staticFiles('assets/js/jquery.ias.min.js') ?>"></script>
<script src="<?php staticFiles('assets/js/jquery.lazyload.min.js') ?>"></script>
<script src="<?php staticFiles('assets/js/highlight.min.js') ?>"></script>
<script src="<?php staticFiles('assets/js/cuckoo.min.js') ?>"></script>
</body>
</html>