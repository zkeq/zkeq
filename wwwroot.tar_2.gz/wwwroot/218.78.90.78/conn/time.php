<?php 
  date_default_timezone_set('PRC');
      $time=date('Y-m-d H:i:s');


?>