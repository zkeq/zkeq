<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>账号注册</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- App css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
		<script type="text/JavaScript" src="./js/jQuery.min.js"></script>
    </head>

    <body class="authentication-bg">

        <div class="account-pages mt-5 mb-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-5">
                        <div class="card">
                            <!-- Logo-->
                            <div class="card-header pt-4 pb-4 text-center bg-primary">
                                <a href="index.html">
                                    <span><img src="assets/images/logo.png" alt="" height="18"></span>
                                </a>
                            </div>

                            <div class="card-body p-4">
                                
                                <div class="text-center w-75 m-auto">
                                    <h4 class="text-dark-50 text-center mt-0 font-weight-bold">Free Sign Up</h4>
                                    <p class="text-muted mb-4">Don't have an account? Create your account, it takes less than a minute </p>
                                </div>

                             

                                    <div class="form-group">
                                        <label for="fullname">用户名</label>
                                        <input class="form-control" type="text" id="fullname" placeholder="Enter your name" required>
                                    </div>

                                    <div class="form-group">
                                        <label for="emailaddress">邮箱地址</label>
                                        <input class="form-control" type="email" id="emailaddress" required placeholder="Enter your email">
                                    </div>

                                    <div class="form-group">
                                        <label for="password">密码</label>
                                        <input class="form-control" type="password" required id="password" placeholder="Enter your password">
                                    </div>

                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="checkbox-signup">
                                            <label class="custom-control-label" for="checkbox-signup">I accept <a href="#" class="text-muted">Terms and Conditions</a></label>
                                        </div>
                                    </div>

                                    <div class="form-group mb-0 text-center">
                                        <button class="btn btn-primary" type="submit" onclick="clickReg()"> Sign Up </button>
                                    </div>

                             
                            </div> <!-- end card-body -->
                        </div>
                        <!-- end card -->

                        <div class="row mt-3">
                            <div class="col-12 text-center">
                                <p class="text-muted">Already have account? <a href="login.php" class="text-muted ml-1"><b>Log In</b></a></p>
                            </div> <!-- end col-->
                        </div>
                        <!-- end row -->

                    </div> <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        <!-- end page -->

        <footer class="footer footer-alt">
            2020 © Wechat - 218.78.90.77:2020
        </footer>
		<script>

			function clickReg(){
			
				var username=$("#fullname").val(),
					email=$("#emailaddress").val(),
					password=$("#password").val();
					if(username=="" || password=="" || email==""){
						alert("信息不能为空");
					}else{
						$.post("api.php?code=reg",
						{	
							username:username,
							email:email,
							password:password
						},
						function(status){
								if(status.success===true){
									var r = confirm("注册成功");
										if (r == true) {
											window.location.href="./login.php";
										} else {
											window.location.href="./login.php";
										}
								}else{
									alert(status.msg);
								}
						});
					}
			}
		</script>
        <!-- App js -->
        <script src="assets/js/app.min.js"></script>
    </body>
</html>
