<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>聊天室登录</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- App css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
		<script type="text/JavaScript" src="./js/jQuery.min.js"></script>

    </head>

    <body class="authentication-bg">

        <div class="account-pages mt-5 mb-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-5">
                        <div class="card">

                            <!-- Logo -->
                            <div class="card-header pt-4 pb-4 text-center bg-primary">
                                <a href="index.html">
                                    <span><img src="assets/images/logo.png" alt="" height="18"></span>
                                </a>
                            </div>

                            <div class="card-body p-4">
                                
                                <div class="text-center w-75 m-auto">
                                    <h4 class="text-dark-50 text-center mt-0 font-weight-bold">Sign In</h4>
                                    <p class="text-muted mb-4">输入你的账号密码</p>
                                </div>

                                

                                    <div class="form-group">
                                        <label for="username">账号</label>
                                        <input class="form-control" type="text" id="username" required="" placeholder="输入你的账号">
                                    </div>

                                    <div class="form-group">
                                        <a href="pages-recoverpw.html" class="text-muted float-right"><small>Forgot your password?</small></a>
                                        <label for="password">密码</label>
                                        <input class="form-control" type="password" required="" id="password" placeholder="输入你的密码">
                                    </div>

                                    <div class="form-group mb-3">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="checkbox-signin" checked>
                                            <label class="custom-control-label" for="checkbox-signin">Remember me</label>
                                        </div>
                                    </div>

                                    <div class="form-group mb-0 text-center">
                                        <button class="btn btn-primary" type="submit" onclick="clickLogin()"> Log In </button>
                                    </div>

                                
                            </div> <!-- end card-body -->
                        </div>
                        <!-- end card -->

                        <div class="row mt-3">
                            <div class="col-12 text-center">
                                <p class="text-muted">Don't have an account? <a href="./register.php" class="text-muted ml-1"><b>Sign Up</b></a></p>
                            </div> <!-- end col -->
                        </div>
                        <!-- end row -->

                    </div> <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        <!-- end page -->

        <footer class="footer footer-alt">
            2020  © Wechat - 218.78.90.77:2020
        </footer>

        <!-- App js -->
		<script>

			function clickLogin(){
			
				var username=$("#username").val(),
					password=$("#password").val();
					if(username=="" || password==""){
						alert("账号密码不能为空");
					}else{
						$.post("api.php?code=login",
						{	
							username:username,
							password:password
						},
						function(status){
								if(status.success===true){
									window.location.href="./index.php";
								}else{
									alert("密码错误");
								}
						});
					}
			}
		</script>
        <script src="assets/js/app.min.js"></script>
		
    </body>
</html>
