//作者:一奇QQ330729121 禁止售卖该源码 仅用于学习用途 
var socket = io.connect("http://218.78.90.77:3333/");

var Xtouxiang = "";
function touxiang(){
	var Touxiang = Math.ceil(Math.random()*5);
	Xtouxiang = "./images/niming"+Touxiang+".png";
	
	return Touxiang;
}
touxiang();
function Time(){
	var date = new Date();
	var year = date.getFullYear();
	var month = date.getMonth()+1;
	var day = date.getDate();
	var hour = date.getHours();
	var minute = date.getMinutes();
	var second = date.getSeconds();
	if(hour.toString().length<2){
		hour="0"+hour;
	}
	if(minute.toString().length<2){
		minute="0"+minute;
	}
	if(second.toString().length<2){
		second="0"+second;
	}
	if(month.toString().length<2){
		month="0"+month;
	}
	if(day.toString().length<2){
		day="0"+day;
	}
var Ztime= year+'-'+month+'-'+day+' '+hour+':'+minute+':'+second;
	return Ztime;
}
function biaoqing(Bid){
	Bid.replace("【微笑】","<img src=\"images/biaoqing/1.png\">");
	Bid.replace("[呲牙]","<img src='images/Face/001@2x.png'>");
	return Bid;
	
}
function removeHTMLTag(str) {
          	str = str.replace(/<\/?[^>]*>/g,''); //去除HTML tag
			str=str.replace(/【微笑】/g,"<img src=\"images/biaoqing/1.png\">");
			str=str.replace(/【快哭了】/g,"<img src=\"images/biaoqing/2.png\">");
			str=str.replace(/【撇嘴】/g,"<img src=\"images/biaoqing/3.png\">");
			str=str.replace(/【色】/g,"<img src=\"images/biaoqing/4.png\">");
			str=str.replace(/【发呆】/g,"<img src=\"images/biaoqing/5.png\">");
			str=str.replace(/【得意】/g,"<img src=\"images/biaoqing/6.png\">");
			str=str.replace(/【流泪】/g,"<img src=\"images/biaoqing/7.png\">");
			str=str.replace(/【害羞】/g,"<img src=\"images/biaoqing/8.png\">");
			str=str.replace(/【闭嘴】/g,"<img src=\"images/biaoqing/9.png\">");
			str=str.replace(/【害羞】/g,"<img src=\"images/biaoqing/10.png\">");
			str=str.replace(/【尴尬】/g,"<img src=\"images/biaoqing/11.png\">");
			str=str.replace(/【发怒】/g,"<img src=\"images/biaoqing/12.png\">");
			str=str.replace(/【吐舌】/g,"<img src=\"images/biaoqing/13.png\">");
			str=str.replace(/【呲牙】/g,"<img src=\"images/biaoqing/14.png\">");
			str=str.replace(/【惊讶】/g,"<img src=\"images/biaoqing/15.png\">");
			str=str.replace(/【难过】/g,"<img src=\"images/biaoqing/16.png\">");
			str=str.replace(/【酷】/g,"<img src=\"images/biaoqing/17.png\">");
			str=str.replace(/【冷汗】/g,"<img src=\"images/biaoqing/18.png\">");
			str=str.replace(/【抓狂】/g,"<img src=\"images/biaoqing/19.png\">");
            return str;
    }

function tzmessage(){
					var gdt = document.getElementById('chat-messages');
					gdt.scrollTop = gdt.scrollHeight;
}

$("#chat-text-btn").click(function(){
	var chatText = $("#chat-text");
	
	var Content = chatText.val(),
		Ztime = Time();
	$.post("charu.php",
    {	
		content:Content,
		time:Ztime,
		touxiang:Xtouxiang
    },
    function(status){
		var head=status.data.header==null?Xtouxiang:status.data.header;
		socket.send(status.data.content,head,status.data.username,status.data.isVip);
    });
	
	
	$("#chat-text").val("")
	
});
$(document).ready(function(){
	tzmessage()
	var chatText = $("#chat-text");
	chatText.keyup(function(event){
		var keyCodezhi = event.keyCode;
		if(keyCodezhi==13){
			var ctval = chatText.val(),
				Ztime = Time();
		//	socket.send(ctval,Xtouxiang);
			$.post("charu.php",
				{	
					content:ctval,
					time:Ztime,
					touxiang:Xtouxiang
				},
				function(status){
						var head=status.data.header==null?Xtouxiang:status.data.header;
						socket.send(status.data.content,head,status.data.username,status.data.isVip);
				});
			
			$("#chat-text").val("")
		
		}
	});
	
});
function playMusic() {
    var audioEle = document.getElementById("newMessageMp3");
    audioEle.load();
    if (audioEle.paused){ /*如果已经暂停*/
        audioEle.play();   //播放
    }else {
        audioEle.pause();  //暂停
    }
}
function audioAutoPlay(){
    var audio = document.getElementById("newMessageMp3");

    var play = function() {
        document.removeEventListener("WeixinJSBridgeReady", play);
        document.removeEventListener("YixinJSBridgeReady", play);

        audio.play();
        audio.pause();
        // document.removeEventListener("touchstart", play, false);
    };
    
    audio.play();
    audio.pause();

    //weixin
    document.addEventListener("WeixinJSBridgeReady", play, false);
    //yixin
    document.addEventListener('YixinJSBridgeReady', play, false);

    // document.addEventListener("touchstart", play, false);
}



socket.on('message',function(mes,head,user,vip){
				
				var div = document.createElement("div"),
					writeMessage = document.getElementById('chat-message'),
					Ztime = Time(),
					xgdate=removeHTMLTag(mes);
					if(vip=="1" || vip==1){
						var color="color:rgb(233, 104, 107);";
					}else{
						var color="color:#444;"
					}
					if($("#sendUser").val()!=user){
						playMusic();
						document.addEventListener("WeixinJSBridgeReady", function () {
							var music = document.getElementById("newMessageMp3");
							music.play();
						}, false);
					}
					
					div.className="lt-left";
					div.innerHTML="<div class=\"lt-left-left\">\
								<img src=\""+head+"\">\
							</div>\
							<div class=\"lt-left-right\">\
								<div class=\"lt-left-right-top\">\
									<span style='"+color+"'>"+user+"</span>\
									<span>"+Ztime+"</span>\
									</div>\
								<div class=\"lt-left-massage\">\
									<span>"+xgdate+"</span>\
								</div>\
							</div>";
					writeMessage.appendChild(div);
					tzmessage()
		});