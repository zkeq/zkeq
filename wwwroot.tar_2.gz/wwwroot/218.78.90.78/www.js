var http = require('http'),
	fs = require('fs'),
	ws = require("socket.io");
var server = http.createServer(function(req,res){
var html = fs.readFileSync("index.php");
	res.setHeader("Content-type","text/html");
	res.end(html);
});
var io = ws(server);
	io.on('connection',function(socket){
		console.log("用户已经连接");
		socket.on('message',function(mes,head,user,vip){
			io.emit('message',mes,head,user,vip);
			
		});
	});
server.listen("3333");